# GRSxE software
The `estimate_gxe.R` file contains the function to estimate the interaction (GxE) between the effects of a polygenic score (GRS) and the environment (E) on an outcome.

The `estimate_gxe` function requires a vector or matrix with the phenotype (`y`) and a second with the associated (`GRS`). It then uses likelihood maximization and estimates the parameter underlying the linear interaction model. It then repeats the procedure using a counterfeit GRS to correct for scale issues.

The `ukb_estimate_gxe` is a helper function which allows GxE interaction to be estimated directly from UK Biobank data. This requires access to the full genetic data and any relevant phenotypes from UK Biobank, as well as a list of SNPs in the form of RSIDs and their effect size estimates. It allows covariates to be specified and corrected for before estimating GxE (age, age^2, sex, and the top 10 genetic PCs are used as covariates by default).

The `get_betas_from_neale` is a helper function to extract SNP RSIDs and effect size estimates from the files provided by the Neale lab, filtering and pruning them based on distance.
